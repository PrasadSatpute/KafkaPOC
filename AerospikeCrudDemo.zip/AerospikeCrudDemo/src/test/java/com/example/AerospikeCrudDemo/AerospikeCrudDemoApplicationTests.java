package com.example.AerospikeCrudDemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AerospikeCrudDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
