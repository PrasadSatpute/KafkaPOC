package com.aerospike.demo.simplespringbootaerospikedemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SimpleSpringbootAerospikeDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SimpleSpringbootAerospikeDemoApplication.class, args);
	}

}
