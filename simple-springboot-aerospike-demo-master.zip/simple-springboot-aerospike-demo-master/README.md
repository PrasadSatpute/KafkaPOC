# Simple web application using Java, Spring Boot, Aerospike database and Docker.

Project tutorial with an easy step-by-step instructions can be found here:

https://medium.com/aerospike-developer-blog/simple-web-application-using-java-spring-boot-aerospike-database-and-docker-ad13795e0089


Project is backed by spring-data-aerospike:

https://github.com/aerospike-community/spring-data-aerospike